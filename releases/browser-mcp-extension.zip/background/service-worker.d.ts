/**
 * Background Service Worker for Browser Inspector Extension
 * Hosts the MCP server and manages tab lifecycle
 */
export {};
//# sourceMappingURL=service-worker.d.ts.map